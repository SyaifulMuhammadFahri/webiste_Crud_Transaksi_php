<?php
class Pelanggan {
    private $conn;
    private $table_name = "tbl_pelanggan";

    public $id;
    public $nama;
    public $email;
    public $telepon;
    public $alamat;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function readAll() {
        $query = "SELECT * FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>
